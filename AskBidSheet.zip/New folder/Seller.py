import requests
from bs4 import BeautifulSoup
import csv
from time import sleep
import os

UserAgent=input("Please enter your nation name: ")
filename="cards_list.txt"
headers = {
    'User-Agent': UserAgent
}

if os.path.exists(filename):
  os.remove(filename)

def build_list():
	final_list = []
	for x, y in zip(soup.find_all('CARDID'), soup.find_all('SEASON')):
		final_list.append("https://www.nationstates.net/page=deck/card="+x.text+"/season="+y.text+"/nation="+name+"\n")
	return final_list
		
def save_list(list):
	print('writeing ' + name + ' now')
	with open(filename, 'a+') as f:
		f.writelines(list)

names = []
with open("names_list.csv") as csv_file:
	csv_reader = csv.reader(csv_file)
	for row in csv_reader:
		names.append(row[0])


		
for index, name in enumerate(names):
	url = "https://www.nationstates.net/cgi-bin/api.cgi?q=cards+deck;nationname="+name
	result = requests.get(url, headers=headers)
	soup = BeautifulSoup(result.content, "xml")
	
	save_list(build_list())
	
	#if index >= 49: #CHECK FOR API LIMITS
	#	print('Sleeping for 30 SECONDS')
	#	sleep(30)   #SLEEP 30 SECONDS